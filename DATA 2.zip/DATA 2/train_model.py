import pandas as pd
from sklearn.ensemble import RandomForestRegressor
import joblib


df = pd.read_csv("Dataset .csv")


df['Has_Table_Booking'] = df['Has Table booking'].apply(lambda x: 1 if x == 'Yes' else 0)
df['Has_Online_Delivery'] = df['Has Online delivery'].apply(lambda x: 1 if x == 'Yes' else 0)

df = df.dropna(subset=['Aggregate rating'])


X = df[['Votes', 'Price range', 'Has_Table_Booking', 'Has_Online_Delivery']]
y = df['Aggregate rating']

model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X, y)


joblib.dump(model, 'rating_model.pkl')

print("✅ Model trained and saved as rating_model.pkl")
