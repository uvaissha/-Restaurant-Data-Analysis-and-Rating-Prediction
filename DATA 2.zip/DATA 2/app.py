import streamlit as st
import joblib

# Add stylish background and CSS
def add_bg_from_url():
    st.markdown(
        f"""
        <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;600&display=swap');

        html, body, [class*="stApp"] {{
            font-family: 'Poppins', sans-serif;
            background-image: url("https://images.ctfassets.net/rric2f17v78a/5wUGU8HJykR17dyVAJLT08/15d4c5e6f79f71a80c4065669a1bcc8a/small-restaurant-business-plan.jpg");
            background-attachment: fixed;
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center;
            color: #ffffff;
        }}

        .main-card {{
            background: rgba(0, 0, 0, 0.6);
            padding: 2rem;
            border-radius: 20px;
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
            backdrop-filter: blur(8px);
            -webkit-backdrop-filter: blur(8px);
            border: 1px solid rgba(255, 255, 255, 0.18);
            max-width: 600px;
            margin: auto;
            margin-top: 3rem;
        }}

        h1, h3 {{
            text-align: center;
        }}

        label, .stRadio label, .stSelectbox label {{
            font-weight: bold !important;
        }}

        .stNumberInput input, .stSelectbox div[data-baseweb="select"], .stRadio {{
            background-color: rgba(255, 255, 255, 0.15);
            border-radius: 10px;
            padding: 0.5rem;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25);
            margin-bottom: 1rem;
        }}

        .stButton button {{
            background-color: #ff6347;
            color: white;
            font-weight: bold;
            border-radius: 10px;
            padding: 0.5rem 1rem;
        }}

        .stButton button:hover {{
            background-color: #ff8266;
        }}
        </style>
        """,
        unsafe_allow_html=True
    )

add_bg_from_url()

model = joblib.load("rating_model.pkl")

st.markdown('<div class="main-card">', unsafe_allow_html=True)

st.title("🍽️ Restaurant Rating Predictor")
st.markdown("### Enter restaurant details:")

votes = st.number_input("Votes", min_value=0, max_value=20000, value=250)
price_range = st.selectbox("Price Range", options=[1, 2, 3, 4])
table_booking = st.radio("Has Table Booking?", ['Yes', 'No'])
online_delivery = st.radio("Has Online Delivery?", ['Yes', 'No'])

has_table = 1 if table_booking == 'Yes' else 0
has_delivery = 1 if online_delivery == 'Yes' else 0

if st.button("Predict Rating"):
    input_data = [[votes, price_range, has_table, has_delivery]]
    predicted_rating = model.predict(input_data)[0]
    st.success(f"🌟 Predicted Aggregate Rating: {predicted_rating:.2f}")

st.markdown('</div>', unsafe_allow_html=True)

